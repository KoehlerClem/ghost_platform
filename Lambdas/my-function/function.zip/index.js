const GhostAdminAPI = require('@tryghost/admin-api');
const api = new GhostAdminAPI({
    url: 'http://random-dev-domain.com',
    key: '6397ca72e0ea780001b49faf:ef47de045e25ae996d49d00e88c574cb9fc47c51a6e1a9d3b230321c82bf6cfd'
});
exports.handler =  async function(event, context) {
    console.log("EVENT: \n" + JSON.stringify(event, null, 2))
    api.posts.browse();
    return context.logStreamName
  }